$(document).ready(function(){
	
	$("#slider ul").jcarousel({
		scroll:1,
		auto:0,
		start:1,
		wrap:"both"
	});
	
});